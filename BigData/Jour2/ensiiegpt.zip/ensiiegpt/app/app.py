import streamlit as st
from streamlit.logger import get_logger
from gptentry import answer
import os
import openai
import numpy as np

def cosine_similarity(a, b):
    return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))

logger = get_logger(__name__)

os.environ['OPENAI_API_KEY']='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'

def get_embedding(text):
    return openai.Embedding.create(input=[text], engine="text-embedding-ada-002")["data"][0]["embedding"]



def main():
    st.set_page_config(
        page_title="Ensiie GPT", page_icon=":rocket:")

    st.header("Ensiie :rocket:")
    message = st.text_area("user message")

    if message:
        st.write("Invoking Ensiie Gpt...")

        message_embeding = get_embedding(message)
        max_similarity = 0
        best_text = ""
        for filename in os.listdir('data'):
            if filename.endswith('.txt'):
                file_path = os.path.join('data', filename)
                with open(file_path, 'r') as file:
                    file_text = file.read()
                    file_embedding = get_embedding(file_text)
                    similarity = cosine_similarity(message_embeding, file_embedding)

                    if similarity >= max_similarity:
                        max_similarity = similarity
                        best_text = file_text
                        message_embeding = file_embedding

        message = best_text
        
        result = answer(message)

        st.info(result)




if __name__ == '__main__':
    main()